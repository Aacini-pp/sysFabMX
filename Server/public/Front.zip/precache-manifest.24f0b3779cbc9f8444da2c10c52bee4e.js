self.__precacheManifest = [
  {
    "revision": "cec6afc2ae7b2a3fc109",
    "url": "/static/css/main.0e38e548.chunk.css"
  },
  {
    "revision": "cec6afc2ae7b2a3fc109",
    "url": "/static/js/main.cec6afc2.chunk.js"
  },
  {
    "revision": "d72d46b2063d48f9773c",
    "url": "/static/js/1.d72d46b2.chunk.js"
  },
  {
    "revision": "53e96ccd61b2d365726d",
    "url": "/static/css/2.f237b1f4.chunk.css"
  },
  {
    "revision": "53e96ccd61b2d365726d",
    "url": "/static/js/2.53e96ccd.chunk.js"
  },
  {
    "revision": "c1af52b4d8c5b62d0852",
    "url": "/static/js/runtime~main.c1af52b4.js"
  },
  {
    "revision": "75f97e04a8945a343db2d575af5def8d",
    "url": "/static/media/blank.75f97e04.png"
  },
  {
    "revision": "6e0fe0a24ec5b85221bd6455fcd58745",
    "url": "/static/media/green-candy.6e0fe0a2.png"
  },
  {
    "revision": "87a15a77ea101c4ddf171f5b8fedf0f6",
    "url": "/static/media/orange-candy.87a15a77.png"
  },
  {
    "revision": "15b06a2ef162d620c54fe551836c8769",
    "url": "/static/media/red-candy.15b06a2e.png"
  },
  {
    "revision": "6a81bb5988d200501bd326e695374ddf",
    "url": "/static/media/yellow-candy.6a81bb59.png"
  },
  {
    "revision": "06e733283fa43d1dd57738cfc409adbd",
    "url": "/static/media/logo.06e73328.svg"
  },
  {
    "revision": "a58ef5ce32f560e2ae7b2d27db0f3531",
    "url": "/static/media/blue-candy.a58ef5ce.png"
  },
  {
    "revision": "7d273338a99262c8ad23e1c50f6c04a5",
    "url": "/static/media/purple-candy.7d273338.png"
  },
  {
    "revision": "ba5ec69413a3b2cedef7d0c94fdb1686",
    "url": "/index.html"
  }
];